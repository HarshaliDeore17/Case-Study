package BankApplication;

public class MMBankFactory extends BankFactory {

	@Override
	public SavingAcc getNewSavingAcc(int accNo, String accName, float accBal, boolean isSalaried) {
		// TODO Auto-generated method stub
		return new MMSavingAcc(accNo,accName,accBal,isSalaried);
	}

	@Override
	public currentAcc getNewcurrentAcc(int accNo, String accName, float accBal, float creditLimit) {
		// TODO Auto-generated method stub
		return new MMcurrentAcc(accNo,accName,accBal,creditLimit);
	}

	
	

}
