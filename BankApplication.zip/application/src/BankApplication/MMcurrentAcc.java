package BankApplication;

public  class MMcurrentAcc extends currentAcc{
	
	public MMcurrentAcc(int accNo, String accName, float accBal, float creditLimit) {
		super(accNo, accName, accBal, creditLimit);
		// TODO Auto-generated constructor stub
	}
	@Override
	public void withdraw(float amount) {
		if(getAccBal()+getCreditLimit()>=amount ) {
			setAccBal(getAccBal()-amount);
		}   
   	 else {
   		 System.out.println("Insufficient amount.withdraw failed");
   	 }
    }
	@Override
	public String toString() {
		return super.toString();
	}
	
		


}
