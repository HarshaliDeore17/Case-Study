package BankApplication;


public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankFactory b1=new MMBankFactory();
		SavingAcc savingacc=new MMSavingAcc(4567,"Harshali",20000,true);
		currentAcc currentacc=new MMcurrentAcc(5467,"Rashi",10000,1000);
		savingacc.withdraw(1000);
		currentacc.withdraw(5000);
		
		System.out.println(savingacc.toString());
		System.out.println(currentacc.toString());
		
		}

	

}
