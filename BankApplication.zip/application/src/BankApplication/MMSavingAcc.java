package BankApplication;

public  class MMSavingAcc extends SavingAcc{
	private static float MINBAL=1000;

	public MMSavingAcc(int accNo, String accName, float accBal, boolean isSalarised) {
		super(accNo, accName, accBal, isSalarised);
  }
	public void withdraw(float amount) {
		if(getAccBal()-amount>=MINBAL) {
			setAccBal(getAccBal()-amount);
		}else {
			System.out.println("Insufficient Balance");
		}
	}
	
			@Override
	public String toString() {
		return super.toString();
	}
}
	
	

	

