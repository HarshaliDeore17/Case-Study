package BankApplication;

public abstract class currentAcc extends BankAcc{
	private final float creditLimit;

	public currentAcc(int accNo, String accName, float accBal, float creditLimit) {
		super(accNo, accName, accBal);
		this.creditLimit = creditLimit;
	}
     public float getCreditLimit() {
    	 return creditLimit;
     }
		
	@Override
	public abstract void withdraw(float amount);
	@Override
	public String toString() {
		return "currentAcc ["+super.toString()+",creditLimit=" + creditLimit + "]";
	}
		
}




