package BankApplication;

public abstract class SavingAcc extends BankAcc {
	private boolean isSalaried;
	private static float MinBal=1000;
	
	public SavingAcc(int accNo, String accName, float accBal, boolean isSalarised) {
		super(accNo, accName, accBal);
		this.isSalaried = isSalarised;
	}
	
	@Override
	public abstract void withdraw(float amount);

	@Override
	public String toString() {
		return "SavingAcc ["+super.toString()+",isSalaried=" + isSalaried + "]";
	}
    	 
	
}
